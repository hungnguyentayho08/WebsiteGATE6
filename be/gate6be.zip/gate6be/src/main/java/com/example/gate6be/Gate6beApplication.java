package com.example.gate6be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gate6beApplication {

	public static void main(String[] args) {
		SpringApplication.run(Gate6beApplication.class, args);
	}

}
