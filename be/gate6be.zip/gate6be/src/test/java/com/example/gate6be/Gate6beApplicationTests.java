package com.example.gate6be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gate6beApplicationTests {

	@Test
	void contextLoads() {
	}

}
